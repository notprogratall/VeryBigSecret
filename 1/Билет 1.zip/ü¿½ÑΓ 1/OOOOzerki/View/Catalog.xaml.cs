﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;

namespace OOOOzerki.View
{
    /// <summary>
    /// Логика взаимодействия для Catalog.xaml
    /// </summary>
    public partial class Catalog : Window
    {
        public Catalog()
        {
            InitializeComponent();
            try
            {
                //установка связи с бд 
                App.DB = new Model.pharmacyEntities();
                MessageBox.Show("успешно подключились к БД", "Проверка подключения", MessageBoxButton.OK, MessageBoxImage.Information);
                

            }
            catch (Exception)//перехватывает все типы исключений
            {
                MessageBox.Show("успешно подключиться к БД не удалось", "Проверка подключения", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            List<Model.Drug> drugs = App.DB.Drug.ToList();
            foreach (Model.Drug drug in drugs)
            {
                drug.Image = GetImage(drug.DrugName);
                //drug.ImagePath = $"/Resources/{imgName}.jpg";
                drug.DiscountPercent = Math.Round(100 * drug.Discount);
                drug.DiscountedPrice = Math.Round(drug.Price - drug.Price * drug.Discount, 2);
            }
                lbDrugs.ItemsSource = drugs;

            // Заполнение cbFilterDiseaseType
            List<DiseaseTypeOptions> diseaseOptions = App.DB.DiseaseType
                .Select(dt => new DiseaseTypeOptions { Name = dt.DiseaseTypeName, Id = dt.DiseaseTypeId })
                .ToList();
            diseaseOptions.Insert(0, new DiseaseTypeOptions { Name = "Все категории" }); // Добавление опции "Все категории"
            cbFilterDiseaseType.ItemsSource = diseaseOptions;
            cbFilterDiseaseType.DisplayMemberPath = "Name";
            cbFilterDiseaseType.SelectedValuePath = "Name";
            cbFilterDiseaseType.SelectedIndex = 0;

            // Заполнение cbSortPrice
            cbSortPrice.Items.Add("По возрастанию");
            cbSortPrice.Items.Add("По убыванию");
            cbSortPrice.SelectedIndex = 0;

       

            // Заполнение cbFilterDiseaseType
            //List<Model.DiseaseType> diseaseTypes = App.DB.DiseaseType.ToList();
            //// Добавление опции "Все категории" вручную
            //cbFilterDiseaseType.Items.Add(new { DiseaseTypeName = "Все категории" });
            //foreach (Model.DiseaseType dt in diseaseTypes)
            //{
            //    cbFilterDiseaseType.Items.Add(dt);
            //}
            //cbFilterDiseaseType.DisplayMemberPath = "DiseaseTypeName";
            //cbFilterDiseaseType.SelectedValuePath = "DiseaseTypeName";
            //cbFilterDiseaseType.SelectedIndex = 0;

        }
        public BitmapImage GetImage(string fileName)
        {
            try
            {
                Uri resourceUri = new Uri($"/Resources/{fileName}.jpg", UriKind.Relative);
                return new BitmapImage(resourceUri);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки изображения: " + ex.Message);
                return null;
            }
        }

        private void UpdateList()
        {
            List<Model.Drug> allDrugs = App.DB.Drug.ToList();

            // Фильтрация по названию
            string searchText = tbSearch.Text.ToLower();
            if (!string.IsNullOrEmpty(searchText))
            {
                allDrugs = allDrugs.Where(d => d.DrugName.ToLower().Contains(searchText)).ToList();
            }

            // Фильтрация по категории болезни
            DiseaseTypeOptions selectedOption = (DiseaseTypeOptions)cbFilterDiseaseType.SelectedItem;

            if (selectedOption != null)
            {
                if (selectedOption.Name != "Все категории")
                {
                    allDrugs = allDrugs.Where(d => d.DiseaseType.DiseaseTypeName == selectedOption.Name).ToList();
                }
            }
               
            // Сортировка по стоимости
            if (cbSortPrice.SelectedIndex == 0) // По возрастанию
            {
                allDrugs = allDrugs.OrderBy(d => d.DiscountedPrice).ToList();
            }
            else if (cbSortPrice.SelectedIndex == 1) // По убыванию
            {
                allDrugs = allDrugs.OrderByDescending(d => d.DiscountedPrice).ToList();
            }

            lbDrugs.ItemsSource = allDrugs;
        }

        private void cbSortPrice_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateList();
            //string selectedValue = cbSortPrice.SelectedValue as string;
            //if (selectedValue == "По возрастанию")
            //{
            //    // получает представление для сортировки
            //    ICollectionView view = CollectionViewSource.GetDefaultView(lbDrugs.ItemsSource);
            //    // очищает старые настройки сортировки.
            //    view.SortDescriptions.Clear();
            //    // добавляет новое правило сортировки по DiscountedPrice.
            //    view.SortDescriptions.Add(new System.ComponentModel.SortDescription("DiscountedPrice", System.ComponentModel.ListSortDirection.Ascending));
            //}
            //else if (selectedValue == "По убыванию")
            //{
            //    ICollectionView view = CollectionViewSource.GetDefaultView(lbDrugs.ItemsSource);
            //    view.SortDescriptions.Clear();
            //    view.SortDescriptions.Add(new System.ComponentModel.SortDescription("DiscountedPrice", System.ComponentModel.ListSortDirection.Descending));
            //}

        }

        private void cbFilterDiseaseType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateList();
            //DiseaseTypeOptions selectedOption = (DiseaseTypeOptions)cbFilterDiseaseType.SelectedItem;

            //// Получение списка всех лекарств
            //List<Model.Drug> allDrugs = App.DB.Drug.ToList();

            //if (selectedOption.Name == "Все категории")
            //{
            //    // Отображение всех лекарств
            //    lbDrugs.ItemsSource = allDrugs;
            //}
            //else
            //{
            //    // Фильтрация по выбранному типу болезни
            //    lbDrugs.ItemsSource = allDrugs.Where(d => d.DiseaseType.DiseaseTypeName == selectedOption.Name).ToList();
            //}

        }

        private void tbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateList();
        }
    }
}
